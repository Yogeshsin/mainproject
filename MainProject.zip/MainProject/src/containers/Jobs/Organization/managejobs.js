import React, { Component } from 'react'

class ManageJobs extends Component {
    render() {
        return (
            <div>
            <div className="jumbotron text-center">

                <h2>Create a new job post </h2>
                <br />
                <h6>Get your open role in front of qualified candidates.</h6>
                <br />
                <div className="col-md-20">
                    <a href="/PostJob" type="submit"  className="btn btn-lg btn-primary" value="post a job" >Post a Job</a>
                </div>
            </div>
            <hr/>
            <img className="img" height="200px" width="30%"  src={require('../User/img1.jpg')} />
            <div className="container">
                  <h4>
                    <b>John Doe</b>
                  </h4>
                 
                  <p>Architect & Engineer</p>
                  <div className="col-md-20">
                    <a href="/viewjobs" type="submit" className="btn btn-lg btn-primary" value="post a job" >View Profile</a>
                </div>
                </div>
        
            <footer>
                    <p><i>By using this site, you agree to LinkedIn terms of use. Commercial use of this site without express authorization is prohibited.

LinkedIn Corporation © 2019</i></p>
            </footer>
            </div>

        )
    }
}

export default ManageJobs;