import React, { Component } from "react";
import ManageJobs from "./Organization/managejobs";
class Jobs extends Component {
    render() {
        return (
            <div>
                <ManageJobs/>
            </div>
        );
    }
}

export default Jobs;